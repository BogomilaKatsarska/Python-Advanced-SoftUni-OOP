from project.aquarium.freshwater_aquarium import FreshwaterAquarium
from project.aquarium.saltwater_aquarium import SaltwaterAquarium
from project.decoration.decoration_repository import DecorationRepository
from project.decoration.ornament import Ornament
from project.decoration.plant import Plant
from project.fish.freshwater_fish import FreshwaterFish
from project.fish.saltwater_fish import SaltwaterFish


class Controller:

    def __init__(self):
        self.decorations_repository = DecorationRepository()
        self.aquariums = []

    def add_aquarium(self, aquarium_type:str, aquarium_name:str):
        aquarium = None
        if aquarium_type == "FreshwaterAquarium":
            aquarium = FreshwaterAquarium(aquarium_name)
        elif aquarium_type == "SaltwaterAquarium":
            aquarium = SaltwaterAquarium(aquarium_name)
        else:
            return "Invalid aquarium type."

        self.aquariums.append(aquarium)
        return f"Successfully added {aquarium_type}."

    def add_decoration(self, decoration_type:str):
        decoration = None
        if decoration_type == "Ornament":
            decoration = Ornament()
        elif decoration_type == "Plant":
            decoration = Plant()
        else:
            return "Invalid decoration type."

        self.decorations_repository.add(decoration)
        return f"Successfully added {decoration_type}."

    def insert_decoration(self, aquarium_name:str, decoration_type:str):
        decoration = self.decorations_repository.find_by_type(decoration_type)
        if decoration == "None":
            return f"There isn't a decoration of type {decoration_type}."

        aquarium = None
        for a in self.aquariums:
            if a.name == aquarium_name:
                aquarium = a
                break

        if aquarium is not None:
            aquarium.add_decoration(decoration)
            self.decorations_repository.remove(decoration)
            return f"Successfully added {decoration_type} to {aquarium_name}."

    def add_fish(self, aquarium_name:str, fish_type:str, fish_name:str, fish_species:str, price:float):
        fish = None
        if fish_type == "FreshwaterFish":
            fish = FreshwaterFish(fish_name, fish_species, price)
        elif fish_type == "SaltwaterFish":
            fish = SaltwaterFish(fish_name, fish_species, price)
        else:
            return f"There isn't a fish of type {fish_type}."

        aquarium = None
        for a in self.aquariums:
            if a.name == aquarium_name:
                aquarium = a
                break

        if fish_type == "FreshwaterFish":
            if type(aquarium).__name__ == "SaltwaterAquarium":  # to learn by heart;
                return "Water not suitable."
        elif fish_type == "SaltwaterFish":
            if type(aquarium).__name__ == "FreshwaterAquarium":
                return "Water not suitable."

        if aquarium is not None:
            result = aquarium.add_fish(fish)
            if result == "Not enough capacity.":
                return result

        return f"Successfully added {fish_type} to {aquarium_name}."

    def feed_fish(self, aquarium_name:str):
        for a in self.aquariums:
            if a.name == aquarium_name:
                a.feed()
                return f"Fish fed: {len(a.fish)}"

    def calculate_value(self, aquarium_name):
        for a in self.aquariums:
            if a.name == aquarium_name:
                sum_price_fish = sum([d.price for d in a.fish])
                sum_price_decor = sum([d.price for d in a.decorations])
                total_sum = sum_price_fish + sum_price_decor
                return f"The value of Aquarium {aquarium_name} is {total_sum:.2f}."

    def report(self) -> str:
        info = [str(aquarium) for aquarium in self.aquariums]
        return '\n'.join(info)