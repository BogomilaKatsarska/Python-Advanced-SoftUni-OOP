from project.hero import Hero


class Elf(Hero):
    def __str__(self):
        return Hero.__str__(self)



