from project.knight import Knight


class DarkKnight(Knight):
    def __str__(self):
        return Knight.__str__(self)