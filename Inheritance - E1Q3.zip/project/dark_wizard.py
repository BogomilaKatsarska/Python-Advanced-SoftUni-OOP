from project.wizard import Wizard


class DarkWizard(Wizard):
    def __str__(self):
        return Wizard.__str__(self)