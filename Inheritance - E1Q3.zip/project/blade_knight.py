from project.dark_knight import DarkKnight


class BladeKnight(DarkKnight):
    def __str__(self):
        return DarkKnight.__str__(self)