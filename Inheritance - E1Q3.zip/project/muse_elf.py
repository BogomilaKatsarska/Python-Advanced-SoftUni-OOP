from project.elf import Elf


class MuseElf(Elf):
    def __str__(self):
        return Elf.__str__(self)