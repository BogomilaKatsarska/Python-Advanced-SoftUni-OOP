from project.hero import Hero


class Wizard(Hero):
    def __str__(self):
        return Hero.__str__(self)