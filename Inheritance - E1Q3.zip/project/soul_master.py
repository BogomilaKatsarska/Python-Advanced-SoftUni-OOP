from project.dark_wizard import DarkWizard


class SoulMonster(DarkWizard):
    def __str__(self):
        return DarkWizard.__str__(self)