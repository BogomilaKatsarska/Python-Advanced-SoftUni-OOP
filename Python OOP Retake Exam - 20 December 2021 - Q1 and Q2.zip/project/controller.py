from project.player import Player
from project.supply.supply import Supply


class Controller:
    def __init__(self):
        self.players = []
        self.supplies = []

    def add_player(self, *players: Player):
        names = []
        for player in players:
            if player not in self.players:
                self.players.append(player)
                names.append(player.name)

        result = f"Successfully added: {', '.join(names)}"
        return result

    def add_supply(self, *supplies: Supply):
        for supply in supplies:
            self.supplies.append(supply)

    def sustain(self, player_name: str, sustenance_type: str):
        if sustenance_type not in ["Food", "Drink"]:
            return

        supply = None
        for s in reversed(self.supplies):
            if sustenance_type == type(s).__name__:
                supply = s
                break

        if sustenance_type == "Food" and supply is None:
            raise Exception("There are no food supplies left!")

        if sustenance_type == "Drink" and supply is None:
            raise Exception("There are no drink supplies left!")

        player = None
        for p in self.players:
            if p.name == player_name:
                player = p
                break

        if player.stamina == 100:
            return f"{player_name} have enough stamina."

        player.set_stamina(supply.energy)
        self.supplies.remove(supply)

        return f"{player_name} sustained successfully with {supply.name}."

    def duel(self, first_player_name: str, second_player_name: str):
        first_player = None
        for p in self.players:
            if p.name == first_player_name:
                first_player = p
                break

        second_player = None
        for p in self.players:
            if p.name == second_player_name:
                second_player = p
                break

        if first_player.stamina <= 0 and second_player.stamina <= 0:
            result = f"Player {first_player_name} does not have enough stamina." + '\n'
            result += f"Player {second_player_name} does not have enough stamina."
            return result

        if first_player.stamina <= 0:
            return f"Player {first_player_name} does not have enough stamina."

        if second_player.stamina <= 0:
            return f"Player {second_player_name} does not have enough stamina."

        winner = None

        if first_player.stamina > second_player.stamina:
            while first_player.stamina > 0 and second_player.stamina >0:
                first_player.stamina = first_player.stamina/2
                second_player.stamina = second_player.stamina/2
                if first_player.stamina < 0:
                    first_player.stamina = 0
                    winner = second_player
                    break
                if second_player.stamina < 0:
                    second_player.stamina = 0
                    winner = first_player
                    break

        else:
            while first_player.stamina > 0 and second_player.stamina > 0:
                second_player.stamina = second_player.stamina / 2
                first_player.stamina = first_player.stamina / 2
                if first_player.stamina < 0:
                    first_player.stamina = 0
                    winner = second_player
                    break
                if second_player.stamina < 0:
                    second_player.stamina = 0
                    winner = first_player
                    break

        if winner is None:
            if first_player.stamina > second_player.stamina:
                winner = first_player
            else:
                winner = second_player

        return f"Winner: {winner.name}"

    def next_day(self):
        for player in self.players:
            player.stamina -= player.age*2
            if player.stamina < 0:
                player.stamina = 0

            food_given = False
            drink_given = False

            for s in self.supplies:
                if "Food" == type(s).__name__ and not food_given:
                    player.stamina += s.energy
                    food_given = True
                elif "Drink" == type(s).__name__ and not drink_given:
                    player.stamina += s.energy
                    drink_given = True