from project.car.car import Car


class MuscleCar(Car):
    def __init__(self, model, speed_limit):
        super().__init__(model, speed_limit)

    @property
    def speed_limit(self):
        return self.__speed_limit

    @speed_limit.setter
    def speed_limit(self, value):
        min_speed_limit = 250
        max_speed_limit = 450
        if not min_speed_limit < value <= max_speed_limit:
            raise ValueError(f"Invalid speed limit! Must be between {min_speed_limit} and {max_speed_limit}!")
        self.__speed_limit = value