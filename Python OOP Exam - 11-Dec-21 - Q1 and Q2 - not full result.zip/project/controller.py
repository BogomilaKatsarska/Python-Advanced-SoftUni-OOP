from project.car.muscle_car import MuscleCar
from project.car.sports_car import SportsCar
from project.driver import Driver
from project.race import Race


class Controller:
    def __init__(self):
        self.cars = []
        self.drivers = []
        self.races = []

    def create_car(self, car_type, model, speed_limit):
        car = None
        if car_type == MuscleCar.__name__:
            car = MuscleCar(model, speed_limit)
        elif car_type == SportsCar.__name__:
            car = SportsCar(model, speed_limit)
        else:
            return

        for c in self.cars:
            if c == car_type:
                raise Exception(f"Car {car.model} is already created!")
        self.cars.append(car)
        return f"{car_type} {model} is created."

    def create_driver(self, driver_name):
        driver = Driver(driver_name)
        for d in self.drivers:
            if d.name == driver.name:
                raise Exception(f"Driver {driver_name} is already created!")
        self.drivers.append(driver)
        return f"Driver {driver_name} is created."

    def create_race(self,race_name):
        race = Race(race_name)
        for r in self.races:
            if r.name == race.name:
                raise Exception(f"Race {race_name} is already created!")
        self.races.append(race)
        return f"Race {race_name} is created."

    def add_car_to_driver(self, driver_name, car_type):
        driver = None
        for drv in self.drivers:
            if drv.name == driver_name:
                driver = drv
                break
        if driver is None:
            raise Exception(f"Driver {driver_name} could not be found!")

        car = None
        for c2 in reversed(self.cars):
            if c2.name == car_type:
                car = c2
                break
        if car is None:
            raise Exception(f"Car {car_type} could not be found!")

        if driver.car is not None:
            old_model = driver.car.model
            driver.car = car
            return f"Driver {driver_name} changed his car from {old_model} to {car_type}."
        else:
            if not car.is_taken:
                car.is_taken = True
                return f"Driver {driver_name} chose the car {car_type}."

    def add_driver_to_race(self, race_name, driver_name):
        race = None
        for r in self.races:
            if race_name == r.name:
                race = r
                break
        if race is None:
            raise Exception(f"Race {race_name} could not be found!")

        driver = None
        for d in self.drivers:
            if driver_name == d.name:
                driver = d
                break
        if driver is None:
            raise Exception(f"Driver {driver_name} could not be found!")

        if driver.car is None:
            raise Exception(f"Driver {driver_name} could not participate in the race!")

        for race in self.races:
            for driver in race.drivers:
                if driver.name == driver_name:
                    raise Exception(f"Driver {driver_name} is already added in {race_name} race.")

        race.drivers.append(driver)
        return f"Driver {driver_name} added in {race_name} race."

    def start_race(self, race_name):
        race = Race(race_name)
        if race not in self.races:
            raise Exception(f"Race {race_name} could not be found!")

        if len(race.drivers) <3:
            raise Exception(f"Race {race_name} cannot start with less than 3 participants!")
        drivers = self.find_racers_for_race(3)

        result = ""
        for driver in drivers:
            driver.win()
            result += f"Driver {driver.name} wins the {race_name} race with a speed of {driver.car.speed_limit}." + "\n"
        return result.strip()

    def find_racers_for_race(self,count):
        return sorted([x for x in self.drivers], key = lambda x: x.car.speed_limit, reverse=True)[0:count]